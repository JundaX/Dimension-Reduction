function [Vs,Ds] = as(edrD)
[dim, nedr] = size(edrD);
A = zeros(dim);
for i = 1:nedr
    B = edrD(:,i);
    A = A + B*B';
end
[V, D] = eig(A);
[~,ind] = sort(diag(D),'descend');
Ds = D(ind,ind);
Vs = V(:,ind);
end