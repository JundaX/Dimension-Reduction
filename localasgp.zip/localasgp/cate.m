function res = cate(X,I)
line = 0;
XI = X(I,:);
XII = XI(:,1);
res.L = sum(XII<line);
res.R = sum(XII>=line);
end