function s = dismix(x, y, alpha)
% alpha \in [0,1]
% x = [locx, gradx]
if nargin < 3
    alpha = 1/2;
end
d2 = size(x,2);
d = d2/2;
n = size(x,1);
m = size(y,1);
locx = x(:,1:d);
gradx = x(:,d+1:end);
locy = y(:,1:d);
grady = y(:,d+1:end);
s = alpha*similar(gradx,grady)+(1-alpha)*pdist2(locx,locy)/(d^.5);

end