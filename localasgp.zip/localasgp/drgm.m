function y = drgm(x,a,B,c,sigma)
% a: k*1 vector
% B: k*1 cell
% c: k*d matrix
n = size(x,1);
y = zeros(n,1);
k = length(a);
for i = 1:n
    for j = 1:k
        Bj = B{j};
        y(i) = y(i) + a(j)*exp(h(x(i,:),Bj,c(j,:),sigma));
    end
end
end


