function y = drgm0(x,a,B,c,sigma,idx)
% a: k*1 vector
% B: k*1 cell
% c: k*d matrix
n = size(x,1);
y = zeros(n,1);
k = length(a);
for i = 1:n
    j = idx(i);
    Bj = B{j};
    y(i) = a(j)*exp(h(x(i,:),Bj,c(j,:),sigma));   
end
end


