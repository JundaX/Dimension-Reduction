function struct0 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, method)
n = size(X,1);
res0.IO = {1:n};
% [~,res0.edrD] = SIR(Y, X, 'cont', 1, 'nslices', 10);
res0.Z = cell(1,1);
if strcmp(method,'sir')
    [~,res0.Z{1},~] = SIR(Y, X, 'cont', dgp, 'nslices', 10);
elseif strcmp(method,'save')
    [~,res0.Z{1},~] = SAVE(Y, X, 'cont', dgp, 'nslices', 10);
end
res0.A = res0.Z{1};
struct0 = drlgp3(X, Y, Xtest, Ytest, res0, ngp, k);
struct0.Z = res0.Z;
end