function struct = drlgp(Xdr, Ydr, Xtest, Ytest, res, ngp)
% use k-nearest-neighbour to classify the test points
N = size(Xtest,1);
Ypred = zeros(size(Ytest));
for i = 1:N
    Xt = Xtest(i,:);
    %     [~, I] = knn(Xdr, Xt, 1);
%     dis = zeros(1,length(res.IO));
    mdis = 1e20;
    mj = 1;
    mI = res.IO{mj};
    for j = 1:length(res.IO)
        Xdrj = Xdr(res.IO{j},:);
%         Ydrj = Ydr(res.IO{j});
        
        [D,I2] = knn(Xdrj*res.Z{j},Xt*res.Z{j},min(ngp,length(res.IO{j})));
        %             [~,I2] = knn(Xdrj,Xt,min(ngp,length(res.IO{j})));
        dis = sum(D(1));
        if dis < mdis
            mdis = dis;
            mj = j;
            mI = I2;
        end
    end
    %% Nonstationary kernel matrix
    Xdrj = Xdr(res.IO{mj},:);
    Ydrj = Ydr(res.IO{mj});
    Xtrain = Xdrj(mI,:)*res.Z{mj};
    Ytrain = Ydrj(mI);
    gprmdl = fitrgp(Xtrain,Ytrain);
    Ypred(i) = predict(gprmdl,Xt*res.Z{mj});
end
%% Error evaluation
struct.relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2;
struct.relerr0 = abs(Ypred-Ytest);
end
