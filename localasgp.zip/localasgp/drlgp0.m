function struct = drlgp0(Xdr, Ydr, Xtest, Ytest, res, ngp)
% use k-nearest-neighbour to classify the test points
N = size(Xtest,1);
Ypred = zeros(size(Ytest));
% lab = label(Xtest);
lab = zeros(N,1);
for i = 1:N
    Xt = Xtest(i,:);
    signX = sign(mean(sign(Xdr(res.IO{1},1))));
    if Xt(1)*signX <= 0
        j = 2;
    else
        j = 1;
    end
    lab(i) = j;
%     if j ~= lab(i)
%         break
%     end
    %     [~, I] = knn(Xdr, Xt, 1);
    %     for j = 1:length(res.IO)
    %         if ismember(I,res.IO{j})
    Xdrj = Xdr(res.IO{j},:);
    Ydrj = Ydr(res.IO{j});
    %             [~,I2] = knn(Xdrj*res.Z{j},Xt*res.Z{j},min(ngp,length(res.IO{j})));
    [~,I2] = knn(Xdrj,Xt,min(ngp,length(res.IO{j})));
    %% Nonstationary kernel matrix
    Xtrain = Xdrj(I2,:)*res.Z{j};
    Ytrain = Ydrj(I2);
    gprmdl = fitrgp(Xtrain,Ytrain);
    Ypred(i) = predict(gprmdl,Xt*res.Z{j});
    %         end
    %     end
end
%% Error evaluation
struct.relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2;
struct.relerr0 = abs(Ypred-Ytest);
struct.label = lab;
end
