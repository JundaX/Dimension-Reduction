function struct = drlgp_grad(Xdr, Ydr, gradXtest, Xtest, Ytest, res, ngp, k)
% use e.d.r. direction to classify the test points
N = size(Xtest,1);
Ypred = zeros(size(Ytest));
for i = 1:N
    Xt = Xtest(i,:);
    A = gradXtest(i,:)';
    opt = similar(A',(res.Z{1}(:,1))');
    opt_index = 1;
    if length(res.Z)>1
        for j = 1:length(res.Z)
            if similar(A',(res.Z{j}(:,1))')<opt
                opt_index = j;
                opt = similar(A',(res.Z{j}(:,1))');
            end
        end
    end
    Xdrj = Xdr(res.IO{opt_index},:);
    Ydrj = Ydr(res.IO{opt_index});
    [~,I2] = knn(Xdrj,Xt,min(ngp,length(res.IO{opt_index})));
    %[~,I2] = knn(Xdrj*res.A,Xt*res.A,min(ngp,length(res.IO{opt_index})));
    %% Nonstationary kernel matrix
    Xtrain = Xdrj(I2,:)*res.Z{opt_index};
    Ytrain = Ydrj(I2);
    gprmdl = fitrgp(Xtrain,Ytrain);
    Ypred(i) = predict(gprmdl,Xt*res.Z{opt_index});
end
%% Error evaluation
struct.relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2;
struct.relerr0 = abs(Ypred-Ytest);
end
