function [If, idx, Z] = edrcluster3grad(X,gradX,dgp,clunum)
% Usage:
%   IO = edrcluster(X,Y,Ic,alpha,MAXITER)
% Inputs:
%   X: n*d matrix,
%   Y: n*1 vector,
%   Ic: 1*nc cells,

%   alpha: threshold
% Outputs:
%   IO: index matrix whose number of columns represents the number of
%   categories
%   edrD: d*nc matrix, represent the nc first e.d.r. directions of nc
%   clusters
%   count: number of misclassifications

%clunum = 1; %number of final clusters
gradX = gradX';
[n,dim] = size(X);
if clunum == 1
    idx = ones(n,1);
else
%     usdist = @(A,B) similar(A,B);
    usdist = @(A,B) dismix(A,B);
%     idx = kmedoids(gradX',clunum,'Distance',usdist);
%     idx = clusterdata(gradX','Distance',usdist,'Maxclust',clunum,'Linkage','ward');
    idx = clusterdata([X gradX'],'Distance',usdist,'Maxclust',clunum,'Linkage','ward');
end
ncf = numel(unique(idx));
If = cell(1,ncf);%final indexes of centers
for i = 1:ncf
    If{i} = find(idx==i);
end
% If = cell(1,ncf);%indexes of final points in clusters
% for i = 1:ncf
%     If{i} = [];
%     for j = 1:length(Icf{i})
%         If{i} = union(If{i},Ic{Icf{i}(j)});
%     end
% end

Z = cell(1,ncf);
for i = 1:ncf
    [B,D] = as(gradX(1:dim,If{i}));
    rdgp = eigdim(D)
    Z{i} = B(:,1:rdgp);
    Z{i} = real(Z{i});
end
end