function d = eigdim(D,alpha)
if nargin < 2
    alpha = 0.7;
end
eigs = diag(D);
d = 1;
s = 0;
eigsum = sum(eigs);
while d <= length(eigs)
    if s < eigsum*alpha
        s = s + eigs(d);
        d = d + 1;
    else
        break
    end   
end
end