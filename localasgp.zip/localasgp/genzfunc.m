function y = genzfunc( indx, ndim, z, alpha, beta )
n = size(z,1);
y = zeros(n,1);
for i = 1:n
    x = z(i,:);
    y(i) = genz_function ( indx, ndim, x, alpha, beta );
end
end