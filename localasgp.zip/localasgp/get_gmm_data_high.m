function theta = get_gmm_data_high(K,d,N,theta)

% alpha = gamrnd(2,.2,N,K);
% alpha = log2(1+alpha);
% alpha = rand(N,K);
% alpha = alpha./repmat(sum(alpha,2),1,K);
alpha0 = theta(1:K);
mu0 = theta(K+1:K*(d+1));
sigma0 = theta(K*(d+1)+1:K*(2*d+1));
cor = .1;
alpha = repmat(alpha0,N,1) + 0*randn(N,K);
mu = repmat(mu0,N,1) + cor*randn(N,K*d);
% mu = randn(N,K*d);
sigma = repmat(sigma0,N,1) + 0*randn(N,K*d);
% sigma = .5*rand(N,K*d) + .01;
figure(2)
muplot = [mu(:,1:2);mu(:,3:4);mu(:,5:6);mu(:,7:8)];
plot(muplot(:,1),muplot(:,2),'x')

theta = [alpha mu sigma];

save('theta.mat','theta')
end