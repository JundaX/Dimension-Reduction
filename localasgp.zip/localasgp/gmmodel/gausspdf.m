function y = gausspdf(x,c,sigma)
d = length(x);
y = 1/(2*pi)^(d/2)/det(sigma)^(1/2)*exp(-(x-c)/sigma*(x-c)'/2);
% disp(['gausspdf:',num2str(y),'.'])
end