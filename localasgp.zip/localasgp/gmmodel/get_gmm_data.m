function theta = get_gmm_data(K,d,N)

% alpha = gamrnd(2,.2,N,K);
% alpha = log2(1+alpha);
alpha = rand(N,K);
alpha = alpha./repmat(sum(alpha,2),1,K);

mu = 2*rand(N,K*d) - 1;
% mu = randn(N,K*d);

sigma = .5*rand(N,K*d) + .01;

theta = [alpha mu sigma];

save('theta.mat','theta')
end