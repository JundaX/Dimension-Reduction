function y = gmmpdf(x,alpha,mu,SIGMA)
d = length(x);
k = length(alpha);
if size(mu,1) ~= k || size(mu,2) ~= d
    error('Number of components in mu and alpha and dimension of x and entries in mu should be consistant')
end
y = 0;
for i = 1:k
    c = mu(i,:);
    sigma = SIGMA{i};
    y = y + alpha(i)*gausspdf(x,c,sigma);
end
% disp(['gmmpdf:',num2str(y),'.'])
end