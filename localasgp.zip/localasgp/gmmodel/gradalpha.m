function grad = gradalpha(X,alpha,mu,SIGMA)
n = size(X,1);
K = length(alpha);
grad = zeros(1,K);
for j = 1:K
    for i = 1:n
        x = X(i,:);
        grad(j) = grad(j) + gausspdf(x,mu(j,:),SIGMA{j})/gmmpdf(x,alpha,mu,SIGMA);
    end
end
end