function grad = gradloglikelihood(X, theta, K, d)
grad = zeros(size(theta,1),K*(2*d+1));
for k = 1:K
    thetak = theta(k,:);
    alpha = thetak(1:K);
    mu = reshape(thetak(K+1:K*(d+1)),d,K)';
    sigma = reshape(thetak(K*(d+1)+1:K*(2*d+1)),d,K)';
    SIGMA = cell(1,K);
    for i = 1:K
        SIGMA{i} = diag(sigma(i,:));
    end
    grad_alpha = gradalpha(X,alpha,mu,SIGMA);
    grad_mu = gradmu(X,alpha,mu,SIGMA);
    grad_sigma = gradsigma(X,alpha,mu,SIGMA);
    grad(k,:) = [grad_alpha grad_mu grad_sigma];
end
end
