function grad = gradmu(X,alpha,mu,SIGMA)
[n, d] = size(X);
K = length(alpha);
grad = zeros(1,K*d);
for j = 1:K
    gradmuj = zeros(1,d);
    for i = 1:n
        x = X(i,:);
        gradmuj = gradmuj + alpha(j)*gausspdf(x,mu(j,:),SIGMA{j})*...
            (x-mu(j,:))/SIGMA{j}/gmmpdf(x,alpha,mu,SIGMA);
    end
    grad((j-1)*d+1:j*d) = gradmuj;
end
end