function grad = gradsigma(X,alpha,mu,SIGMA)
[n, d] = size(X);
K = length(alpha);
grad = zeros(1,K*d);
for j = 1:K
    gradsigmaj = zeros(1,d);
    sigmaj = diag(SIGMA{j})';
    for i = 1:n
        x = X(i,:);
        gradsigmaj = gradsigmaj + alpha(j)*gausspdf(x,mu(j,:),SIGMA{j})*...
            ((x-mu(j,:)).^2./sigmaj.^2)/2/gmmpdf(x,alpha,mu,SIGMA);
    end
    grad((j-1)*d+1:j*d) = gradsigmaj;
end
end