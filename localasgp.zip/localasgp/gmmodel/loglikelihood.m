function prob = loglikelihood(X, theta, K, d)
prob = zeros(size(theta,1),1);
for k = 1:size(theta,1)
    thetak = theta(k,:);
    alpha = thetak(1:K);
    mu = reshape(thetak(K+1:K*(d+1)),d,K)';
    sigma = reshape(thetak(K*(d+1)+1:K*(2*d+1)),d,K)';
    [n, ~] = size(X);
    SIGMA = cell(1,K);
    for i = 1:K
        SIGMA{i} = diag(sigma(i,:));
    end
    for i = 1:n
        x = X(i,:);
        prob(k) = prob(k) + log(gmmpdf(x,alpha,mu,SIGMA));
    end
end
end