function [a,B,c] = gmpar(clu,dim)
% clu = 4;
% dim = 50;
a = gamrnd(2,.2,1,clu);
a = log2(1+a);
a = a/sum(a);
B = cell(1,clu);
for i = 1:clu
    B{i} = binornd(1,.08,dim,unidrnd(4));
end
c = 1*cos(pi*rand(clu,dim));
%sigma = .5;
% save('a.mat','a')
% save('B.mat','B')
% save('c.mat','c')
end
