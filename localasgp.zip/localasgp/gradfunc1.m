function y = gradfunc1(x)
[n,d] = size(x);
y = zeros(n,d);
for i = 1:n
    y(i,:) = [0 (x(i,5) + x(i,6) + x(i,7) + 1)*ones(1,3) (x(i,4) + x(i,2) + x(i,3))*ones(1,3) zeros(1,d-7)];   
end
end