function y = gradfunc2(x)
[n,d] = size(x);
y = zeros(n,d);
for i = 1:n
    if x(i,1) < 0
        y(i,:) = [0 x(i,5)*ones(1,3) x(i,2)+x(i,3)+x(i,4)+1 zeros(1,d-5)];
    else
        y(i,:) = [zeros(1,5) (x(i,9)+x(i,10))*ones(1,3) (x(i,8) + x(i,6) + x(i,7) + 1)*ones(1,2) zeros(1,d-10)];
    end
end
end