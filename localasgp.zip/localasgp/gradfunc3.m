function y = gradfunc3(x)
[n,d] = size(x);
y = zeros(n,d);
for i = 1:n
    if x(i,1) < 0 && x(i,2) < 0
        y(i,:) = [zeros(1,2) x(i,5)*ones(1,2) (x(i,4) + x(i,3) + 1) zeros(1,d-5)];
    elseif x(i,1) < 0 && x(i,2) >= 0
        y(i,:) = [zeros(1,5) (x(i,9) + x(i,8))*ones(1,2) (x(i,6) + x(i,7) + 1)*ones(1,2) zeros(1,d-9)];
    elseif x(i,1) >= 0 && x(i,2) < 0
        y(i,:) = [zeros(1,9) ones(1,2) zeros(1,d-11)];
    elseif x(i,1) >= 0 && x(i,2) >= 0
        y(i,:) = [zeros(1,11) x(i,13) (x(i,12) + 1) zeros(1,d-13)];    
    end
end
end