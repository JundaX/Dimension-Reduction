function gradX = gradgenzfunc( indx, ndim, z, alpha, beta )
n = size(z,1);
gradX = zeros(n,ndim);
if indx == 1
    for i = 1:n
        x = z(i,:);
        gradX(i,:) = -sin(2.0 * pi * beta(1) + x * alpha').*alpha;
    end
elseif indx == 2
    error('indx can only be 1.')
elseif indx == 3
    for i = 1:n
        x = z(i,:);
        total = 1.0;
        for j = 1 : ndim
            if ( beta(j) < 0.5 )
                total = total + z(j);
            else
                total = total + alpha(j) - z(j);
            end
        end
        gradX(i,:) = - ndim * total^(-ndim-1) .* sign(1/2 - beta);
    end
end


