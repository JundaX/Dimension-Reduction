function y = gradgm(x,a,B,c,sigma)
% a: k*1 vector
% B: k*1 cell
% c: k*d matrix
[n, d] = size(x);
y = zeros(n,d);
k = length(a);
for i = 1:n
    for j = 1:k
        Bj = B{j};
        y(i,:) = y(i,:) - a(j)*exp(h(x(i,:),Bj,c(j,:),sigma))/...
            sigma^2*(x(i,:)-c(j,:))*(Bj*Bj');
    end
end
end


