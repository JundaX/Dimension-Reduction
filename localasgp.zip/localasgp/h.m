function y = h(x,B,c,sigma)
n = size(x,1);
y = zeros(n,1);
for i =1:n
    y(i) = -1/(2*sigma^2)*norm((x(i,:)-c)*B)^2;
end
end