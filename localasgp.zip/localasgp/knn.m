function [D, I] = knn(X, Y, k)
% This algorithm finds k-nearest-neighbours in X for every elements in Y
% based on euclidean distance
% Inputs:
%   X: n*p matrix of neighbour set
%   Y: m*p matrix of test set
% Outputs:
%   D: k*m matrix of k smallest euclidean distance for every elements in Y
%   with respect to elements in X
%   I: k*m indices matrix
[D, I] = pdist2(X, Y, 'euclidean', 'Smallest', k);
end