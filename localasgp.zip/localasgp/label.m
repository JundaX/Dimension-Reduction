function lab = label(X,func,res,Xt)
if nargin<4
    Xt = X;
end
if strcmp(func,'testfunc2')
    sign1 = sign(X(res.IO{1}(1),1));
    if sign1<0
        y = Xt(:,1)<0;
        lab = 2 - y;
    else
        y = Xt(:,1)>=0;
        lab = 2 - y;
    end
elseif strcmp(func,'testfunc3')
    %     lab = zeros(size(Xt,1),1);
    %     for i = 1:4
    %         y = sublabel4(X(res.IO{i}(1),1:2));
    %         lab(res.IO{i}) = y;
    %     end
    y = Xt(:,1)>=0;
    lab = 2 - y;
end
end

