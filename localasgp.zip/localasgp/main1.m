function res = main1(X,gradX,dgp,clunum)
% require 
%   X: input,
%   Y: output, 
%   nc: number of cluster centers

[IO, idx, Z] = edrcluster3grad(X,gradX,dgp,clunum);
res.IO = IO;
res.Z = Z;
res.lab = idx;
end