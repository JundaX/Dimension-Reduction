# This code produces the figures for the paper Active subspace methods in theory and practice by Constantine, Dow, and Wang.
