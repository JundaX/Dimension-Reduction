function struct = drlgpclass(Xdr, Ydr, Xtest, Ytest, res, ngp, method)
% use k-nearest-neighbour to classify the test points
N = size(Xtest,1);
Ypred = zeros(size(Ytest));
test_label = label(Xdr,'testfunc2',res,Xtest);
% numel(unique(res.lab))
% numel(unique(test_label))
%method = 'SVM';
[~, predict_label] = matclass(Xdr, res.lab, Xtest, test_label, method);
% unique(predict_label)
% unique(test_label)
% accuracy
for i = 1:N
    Xt = Xtest(i,:);
    j = predict_label(i);
    Xdrj = Xdr(res.IO{j},:);
    Ydrj = Ydr(res.IO{j});
%     [~,I2] = knn(Xdrj*res.Z{j},Xt*res.Z{j},min(ngp,length(res.IO{j})));
    [~,I2] = knn(Xdrj,Xt,min(ngp,length(res.IO{j})));
    %% Nonstationary kernel matrix
    Xtrain = Xdrj(I2,:)*res.Z{j};
    Ytrain = Ydrj(I2);
    gprmdl = fitrgp(Xtrain,Ytrain);
    Ypred(i) = predict(gprmdl,Xt*res.Z{j});
end
%% Error evaluation
struct.relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2;
struct.relerr0 = abs(Ypred-Ytest);
struct.label = predict_label;
% struct.accuracy = accuracy;
end
