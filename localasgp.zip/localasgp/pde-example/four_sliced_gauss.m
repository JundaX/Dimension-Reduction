function C = four_sliced_gauss(corr, mesh1, mesh2, matvec, x)
c01 = corr.c01;
c02 = corr.c02;
c03 = corr.c03;
c04 = corr.c04;
c012 = corr.c012;
c013 = corr.c013;
c014 = corr.c014;
c023 = corr.c023;
c024 = corr.c024;
c034 = corr.c034;
sigma = corr.sigma;
I1 = find(mesh1(:,1)>1/2);
I2 = setdiff(1:m,I11);

C1 = zeros(m,2);
C1(I1,:) = repmat(c01',length(I1),1);
C1(I2,:) = repmat(c03',length(I2),1);
C2 = zeros(m,2);
C2(I1,:) = repmat(c02',length(I2),1);
C2(I2,:) = repmat(c03',length(I1),1);
if matvec
    x=x.*sigma; x=x';
    C=zeros(m,1);
    parfor i=1:n
        point=mesh2(i,:);
        X=(mesh1-repmat(point,m,1)).^2;
        if point(1)>1/2
            C(i)=x*(exp(sum(X.*C1,2)));
        else
            C(i)=x*(exp(sum(X.*C2,2)));
        end
    end
else
    C=zeros(m,n);
    parfor i=1:n
        point=mesh2(i,:);
        X=(mesh1-repmat(point,m,1)).^2;
        if point(1)>1/2
            C(:,i)=sigma.*(exp(sum(X.*C1,2)));
        else
            C(:,i)=sigma.*(exp(sum(X.*C2,2)));
        end
    end
end
end