function [U] = piecewise_constant_bases(m,pde_data,filename)

% corr_length: correlation length
% m: truncation of KL
% pde_data: mesh for PDE

filename = sprintf('kl/%s',filename);

% Random field model for diffusion coefficients.
if exist(filename,'file')
    % If the PDEs have been solved, use 'em.
    load(filename);
else
    mesh = pde_data.p'; % of size n*2
    if m ~= 100
        error('The number of basis should be 100.')
    end
    loca = ceil(mesh*10);
    loca(loca==0) = 1;
    indx = loca(:,1) + 10*(loca(:,2) - 1);
    N = size(mesh,1);
    U = zeros(N,m);
    U(sub2ind(size(U),1:N,indx')) = 2;
    save(filename,'U');
end