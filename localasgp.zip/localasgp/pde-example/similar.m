function s = similar(x, y)
% This function computes the similarity for vectors in x and y
% Input:
%   x: n*d vector
%   y: m*d vector
n = size(x,1);
m = size(y,1);
s = x*y'./(repmat(vecnorm(x,2,2),1,m).*repmat(vecnorm(y,2,2)',n,1));
s = 1 - abs(s);
end