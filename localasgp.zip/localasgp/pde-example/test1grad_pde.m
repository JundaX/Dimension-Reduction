clear;
%run('/home/qqding/Junda/toolbox/LDR/setpaths.m')
% rng('default')
dim = 100;

ngp = 1000;

pde_data = get_pde_data();

corr_length = 1;
% Load the initial random study
% T=load('gp/testing0.mat'); X0 = T.X; clear T;
% M is number of samples
% m is dimension of space
% [M,m] = size(X0);

% Get the PDE solutions and gradients
% if corr_length == 1
%     filename='long_corr.mat';
%     testfilename='test_long_corr.mat';
%     trainfilename='train_long_corr.mat';
% elseif corr_length == 0.01
%     filename='short_corr.mat';
%     testfilename='test_short_corr.mat';
%     trainfilename='train_short_corr.mat';
% else
%     filename=sprintf('%0.10d.mat',randi(1e9));
% end
% [U,~] = get_kl_bases(corr_length,m,pde_data,filename);
trainfilename = 'mytrain2.mat';
testfilename = 'mytest2.mat';
%% 
% gradX = gradfunc(X);
% gradXtest = gradfunc(Xtest);

T=load('gp/train_full.mat'); X = T.X; clear T;
[~, m] = size(X);
% [U,svtrain] = get_kl_bases(corr_length,m,pde_data,trainfilename);
[U] = piecewise_constant_bases(m,pde_data,trainfilename);
[Y, gradX]= get_pde_solutions(X,U,pde_data,trainfilename);
Y = real(Y);
gradX = real(gradX);
T=load('gp/test_full.mat'); Xtest = T.X; clear T;
% [Utest,svtest] = get_kl_bases(corr_length,m,pde_data,testfilename);
[Utest] = piecewise_constant_bases(m,pde_data,testfilename);
[Ytest, gradXtest]= get_pde_solutions(Xtest,Utest,pde_data,testfilename);
Ytest = real(Ytest);
gradXtest = real(gradXtest);
% k = round(4*Ntrain/nc);
k = 200;
disp(['dim = ',num2str(dim)])
%% local
for dgp = 1:1:4
for clunum = 1:1:4
disp(['dgp = ',num2str(dgp),', clunum = ',num2str(clunum),'.'])
disp(['local'])

res = main1(X,gradX,dgp,clunum);

% train_label = label(X,'testfunc2',res);
% train_accuracy = length(find(res.lab == train_label))/length(train_label)*100;
% disp(['train_accuracy = ',num2str(train_accuracy),'%.'])

% accuracy = matclass(X, res.lab, Xtest, test_label, 'RF')
% struct = drlgpclassgrad(X, gradX, Y, Xtest, gradXtest, Ytest, res, ngp, 'SVM');
% struct = drlgp_grad(X, Y, gradXtest, Xtest, Ytest, res, ngp, k);
struct = drlgpclass(X, Y, Xtest, Ytest, res, ngp, 'SVM');
% struct = drlgpclass0(X, Y, Xtest, Ytest, gradXtest, clunum, res, ngp, 'SVM');
% numel(unique(struct.label))
disp(['as = ',num2str(struct.relerr),'%.'])
% disp(['test_classification_accuracy = ',num2str(struct.accuracy),'%.'])
end
%% global
%  disp(['global'])
%  struct0 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'sir');
%  disp(['sir = ',num2str(struct0.relerr),'%.'])
%  
%  struct00 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'save');
%  disp(['save = ',num2str(struct00.relerr),'%.'])
end

%% direct gp
% disp(['direct gp'])
% Ypred = zeros(size(Ytest));
% for i = 1:size(Ytest,1)
%     Xt = Xtest(i,:);
%     [~, I] = knn(X, Xt, ngp);
%     Xtrain = X(I,:);
%     Ytrain = Y(I);
%     gprMdl = fitrgp(Xtrain,Ytrain);
%     Ypred(i) = predict(gprMdl,Xt);
% end
% relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2;
% disp(['direct gp = ',num2str(relerr),'%.'])





