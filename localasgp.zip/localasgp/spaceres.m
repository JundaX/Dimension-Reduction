function res_norm = spaceres(B,A,dim)
[nsamp,~] = size(A);
B = reshape(B',dim,[])';
res_norm = zeros(nsamp,1);
for i = 1:nsamp
    C = reshape(A(i,:)',dim,[]);
    dgp = size(C,2);
    par = B*C./repmat(diag(C'*C)',size(B,1),1);
    appr = zeros(size(B));
    for j = 1:dgp
        appr = appr + par(:,j).*C(:,j)';
    end
    res = B - appr;
    r2norm = sum(B.^2,2);
    res_norm(i) = sum(sum(res.^2,2)./r2norm);
end
end