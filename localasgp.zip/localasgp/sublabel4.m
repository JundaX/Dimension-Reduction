function y = sublabel4(x)

if x(1)*x(2)>0
    if x(1)>0
        y = 1;
    else
        y = 3;
    end
else
    if x(1)>0
        y = 4;
    else
        y = 2;
    end
end
end