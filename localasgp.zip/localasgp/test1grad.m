clear;
%run('/home/qqding/Junda/toolbox/LDR/setpaths.m')
% rng('default')
n = 1e3;
%dim = 100;
for dim = 50:-10:50
    % nc = 500;
    Ntest = 500;
    ngp = 1000;
    
    % route = '4piece';
    route = '3pgm2';
    % [a,B,c] = gmpar(3,dim);
    % save(fullfile(route,'a.mat'),'a');
    % save(fullfile(route,'B.mat'),'B');
    % save(fullfile(route,'c.mat'),'c');
    %
    load(fullfile(route,'a.mat'),'a');
    load(fullfile(route,'B.mat'),'B');
    load(fullfile(route,'c.mat'),'c');
    sigma = .2;
    %% function
    % func = @(x) genzfunc( indx, dim, x, alpha, beta );
    %  func = @(x) testfunc3(x);
    func = @(x) drgm(x,a,B,c,sigma);
    % idx = randsrc(n,1,[1:length(a);a]);
    % idx_test = randsrc(Ntest,1,[1:length(a);a]);
    % func = @(x, idx) drgm0(x,a,B,c,sigma,idx);
    %% gradients of function
    % gradfunc = @(x) gradgenzfunc( indx, dim, x, alpha, beta );
    %  gradfunc = @(x) gradfunc3(x);% + .2*randn(size(x));
    gradfunc = @(x) gradgm(x,a,B,c,sigma);% + .05*randn(size(x));
    % gradfunc = @(x) gradgm0(x,a,B,c,sigma,idx);
    
    %%
    % X = 2*rand(n,dim)-1;
    % Y = func(X);
    % Xtest = 2*rand(Ntest,dim)-1;
    % Ytest = func(Xtest);
    %
    % save(fullfile(route,'X.mat'),'X')
    % save(fullfile(route,'Y.mat'),'Y')
    % save(fullfile(route,'Xtest.mat'),'Xtest')
    % save(fullfile(route,'Ytest.mat'),'Ytest')
    
    load(fullfile(route,'X.mat'),'X')
    load(fullfile(route,'Y.mat'),'Y')
    load(fullfile(route,'Xtest.mat'),'Xtest')
    load(fullfile(route,'Ytest.mat'),'Ytest')
    
    %%
    gradX = gradfunc(X);
    gradXtest = gradfunc(Xtest);
    [Ntrain, ~] = size(X);
    % k = round(4*Ntrain/nc);
    k = 200;
    disp(['dim = ',num2str(dim)])
    %% local
    for dgp = 1:1:1       
        for clunum = 1:1:4
            disp(['dgp = ',num2str(dgp),', clunum = ',num2str(clunum),'.'])
            disp(['local'])
            res = main1(X,gradX,dgp,clunum);
            
            % train_label = label(X,'testfunc2',res);
            % train_accuracy = length(find(res.lab == train_label))/length(train_label)*100;
            % disp(['train_accuracy = ',num2str(train_accuracy),'%.'])
            
            % accuracy = matclass(X, res.lab, Xtest, test_label, 'RF')
            
            struct = drlgpclass(X, Y, Xtest, Ytest, res, ngp, 'SVM');
            % struct = drlgpclassgrad(X, gradX, Y, Xtest, gradXtest, Ytest, res, ngp, 'SVM');
            
            % struct = drlgp_grad(X, Y, gradXtest, Xtest, Ytest, res, ngp, k);
            % struct = drlgpclass0(X, Y, Xtest, Ytest, gradXtest, clunum, res, ngp, 'SVM');
            % numel(unique(struct.label))
            
            disp(['as = ',num2str(struct.relerr),'%.'])
            % disp(['test_classification_accuracy = ',num2str(struct.accuracy),'%.'])
        end
        %% global
        %  disp(['global'])
        %  struct0 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'sir');
        %  disp(['sir = ',num2str(struct0.relerr),'%.'])
        %
        %  struct00 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'save');
        %  disp(['save = ',num2str(struct00.relerr),'%.'])
    end
    
    %% direct gp
    % disp(['direct gp'])
    % Ypred = zeros(Ntest,1);
    % for i = 1:Ntest
    %     Xt = Xtest(i,:);
    %     [~, I] = knn(X, Xt, ngp);
    %     Xtrain = X(I,:);
    %     Ytrain = Y(I);
    %     gprMdl = fitrgp(Xtrain,Ytrain);
    %     Ypred(i) = predict(gprMdl,Xt);
    % end
    % relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2;
    % disp(['gp = ',num2str(relerr),'%.'])
end
