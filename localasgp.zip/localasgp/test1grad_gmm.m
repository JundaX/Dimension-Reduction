clear;
%run('/home/qqding/Junda/toolbox/LDR/setpaths.m')
% rng('default')
Ntrain = 1e3;

K = 5;
d = 2;
Ntest = 2e2;
ngp = 1000;
%% Gaussian Mixture Sampler
% center = 4*rand(3,d)-2;
% SIG = 3*rand(3,d) + .01;
% Xloc1 = randn(400,d)*diag(SIG(1,:).^.5) + center(1,:);
% Xloc2 = randn(300,d)*diag(SIG(2,:).^.5) + center(2,:);
% Xloc3 = randn(300,d)*diag(SIG(3,:).^.5) + center(3,:);
% Xloc = [Xloc1; Xloc2; Xloc3];
% save('center.mat','center')
% save('SIG.mat','SIG')
% save('Xloc2d.mat','Xloc')
% plot(center(:,1),center(:,2),'x')
load('weight.mat','weight')
load('center.mat','center')
load('SIG.mat','SIG')
theta_true = [weight zeros(1,K-3) reshape(center',1,3*d)...
    zeros(1,(K-3)*d) reshape(SIG',1,3*d) ones(1,d*(K-3))];
load('Xloc2d.mat','Xloc')
% Xtest = zeros(Ntest,K*(2*d+1));
% for i = 1:Ntest
%     Xtest(i,:) = [.4 .3 .3 0 0 reshape(center',1,3*d) 4*rand(1,(K-3)*d)-2 reshape(SIG',1,3*d) 3*rand(1,(K-3)*d)+.01];
% end
% load('Xloc2d.mat','Xloc')
% load('Xloc.mat','Xloc')

%% function
func = @(theta) loglikelihood(Xloc, theta, K, d);
% func = @(x) genzfunc( indx, dim, x, alpha, beta );
%  func = @(x) testfunc2(x);
% func = @(x) drgm(x,a,B,c,sigma);
% idx = randsrc(n,1,[1:length(a);a]);
% idx_test = randsrc(Ntest,1,[1:length(a);a]);
% func = @(x, idx) drgm0(x,a,B,c,sigma,idx);
%% gradients of function
gradfunc = @(theta) gradloglikelihood(Xloc, theta, K, d);
% gradfunc = @(x) gradgenzfunc( indx, dim, x, alpha, beta );
%  gradfunc = @(x) gradfunc2(x);
% gradfunc = @(x) gradgm(x,a,B,c,sigma);
% gradfunc = @(x) gradgm0(x,a,B,c,sigma,idx);

%%
X = get_gmm_data(K,d,Ntrain);
% X = get_gmm_data_high(K,d,Ntrain,theta_true);
Y = func(X);
% range(Y)
Xtest = get_gmm_data(K,d,Ntest);
% Xtest = get_gmm_data_high(K,d,Ntest,theta_true);
Ytest = func(Xtest);
% save('X.mat','X')
% save('Y.mat','Y')
% save('Xtest.mat','Xtest')
% save('Ytest.mat','Ytest')

% load('X.mat','X')
% load('Y.mat','Y')
% load('Xtest.mat','Xtest')
% load('Ytest.mat','Ytest')



%%
gradX = gradfunc(X);
gradXtest = gradfunc(Xtest);

% k = round(4*Ntrain/nc);
k = 200;
% disp(['dim = ',num2str(d)])
%% local
for dgp = 4:4:4
    for clunum = 1:1:2
        disp(['dgp = ',num2str(dgp),', clunum = ',num2str(clunum),'.'])
        disp(['local'])
        
        res = main1(X,gradX,dgp,clunum);
        
        % train_label = label(X,'testfunc2',res);
        % train_accuracy = length(find(res.lab == train_label))/length(train_label)*100;
        % disp(['train_accuracy = ',num2str(train_accuracy),'%.'])
        
        % accuracy = matclass(X, res.lab, Xtest, test_label, 'RF')
        struct = drlgpclass(X, Y, Xtest, Ytest, res, ngp, 'SVM');
        % struct = drlgpclass0(X, Y, Xtest, Ytest, gradXtest, clunum, res, ngp, 'SVM');
        % numel(unique(struct.label))
        disp(['as = ',num2str(struct.relerr),'%.'])
        % disp(['test_classification_accuracy = ',num2str(struct.accuracy),'%.'])
    end
    %% global
    disp(['global'])
    struct0 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'sir');
    disp(['sir = ',num2str(struct0.relerr),'%.'])
    
    struct00 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'save');
    disp(['save = ',num2str(struct00.relerr),'%.'])
end

%% direct gp
disp(['direct gp'])
Ypred = zeros(Ntest,1);
for i = 1:Ntest
    Xt = Xtest(i,:);
    [~, I] = knn(X, Xt, ngp);
    Xtrain = X(I,:);
    Ytrain = Y(I);
    gprMdl = fitrgp(Xtrain,Ytrain);
    Ypred(i) = predict(gprMdl,Xt);
end
relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2;
disp(['gp = ',num2str(relerr),'%.'])

%% linear
disp(['linear'])
B = regress(Y,[ones(Ntrain,1) X]);
Ypred_linear = [ones(Ntest,1) Xtest]*B;
relerr_linear = 100*norm(Ypred_linear-Ytest)^2/norm(Ytest)^2;
disp(['linear = ',num2str(relerr_linear),'%.'])

% end
