clear;
%run('/home/qqding/Junda/toolbox/LDR/setpaths.m')
% rng('default')
% n = 2e3;
%dim = 100;
for dim = 100:-10:100
% nc = 500;
% Ntest = 500;
ngp = 1000;

% w = 0.3;
% load('c50.mat','c50')
% func = @(x) genz ( x, c50, w );
%indx = 2; 
%alpha = gamrnd(1,1,1,dim);
%beta = rand(1,dim);
%func = @(x) genzfunc( indx, dim, x, alpha, beta );
%for reptime = 1:1
%run('/home/qqding/Junda/HDDRLocalGP/gmpar.m')
% [a,B,c] = gmpar(2,dim);
% load('a.mat','a');
% load('B.mat','B');
% load('c.mat','c');
% sigma = .2;
%% function
%  func = @(x) testfunc3(x);
% func = @(x) drgm(x,a,B,c,sigma);
% idx = randsrc(n,1,[1:length(a);a]);
% idx_test = randsrc(Ntest,1,[1:length(a);a]);
% func = @(x, idx) drgm0(x,a,B,c,sigma,idx);
%% gradients of function
%  gradfunc = @(x) gradfunc3(x);
% gradfunc = @(x) gradgm(x,a,B,c,sigma);
% gradfunc = @(x) gradgm0(x,a,B,c,sigma,idx);

%% 
% X = 2*rand(n,dim)-1;
% Y = func(X);
% Xtest = 2*rand(Ntest,dim)-1;
% Ytest = func(Xtest);
% save('X.mat','X')
% save('Y.mat','Y')
% save('Xtest.mat','Xtest')
% save('Ytest.mat','Ytest')

% load('X.mat','X')
% load('Y.mat','Y')
% load('Xtest.mat','Xtest')
% load('Ytest.mat','Ytest')

pde_data = get_pde_data();

%% 
% gradX = gradfunc(X);
% gradXtest = gradfunc(Xtest);

T=load('paulcom-as/gp/test_full.mat'); Xtest = T.X; clear T;

[Ytest, gradXtest]= get_pde_solutions(Xtest,U,pde_data,testfilename);
T=load('paulcon-as/gp/train_full.mat'); X = T.X; clear T;

[Ytrain, gradX]= get_pde_solutions(X,U,pde_data,trainfilename);

% k = round(4*Ntrain/nc);
k = 200;
disp(['dim = ',num2str(dim)])
%% local
for dgp = 2:4:2
for clunum = 1:1:2
disp(['dgp = ',num2str(dgp),', clunum = ',num2str(clunum),'.'])
disp(['local'])

res = main1(X,gradX,dgp,clunum);

% train_label = label(X,'testfunc2',res);
% train_accuracy = length(find(res.lab == train_label))/length(train_label)*100;
% disp(['train_accuracy = ',num2str(train_accuracy),'%.'])

% accuracy = matclass(X, res.lab, Xtest, test_label, 'RF')
struct = drlgpclass(X, Y, Xtest, Ytest, res, ngp, 'SVM');
% struct = drlgpclass0(X, Y, Xtest, Ytest, gradXtest, clunum, res, ngp, 'SVM');
% numel(unique(struct.label))
disp(['as = ',num2str(struct.relerr),'%.'])
% disp(['test_classification_accuracy = ',num2str(struct.accuracy),'%.'])
end
%% global
 disp(['global'])
 struct0 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'sir');
 disp(['sir = ',num2str(struct0.relerr),'%.'])
 
 struct00 = drgp(X, Y, Xtest, Ytest, ngp, dgp, k, 'save');
 disp(['save = ',num2str(struct00.relerr),'%.'])
end

%% direct gp
disp(['direct gp'])
Ypred = zeros(Ntest,1);
for i = 1:Ntest
    Xt = Xtest(i,:);
    [~, I] = knn(X, Xt, ngp);
    Xtrain = X(I,:);
    Ytrain = Y(I);
    gprMdl = fitrgp(Xtrain,Ytrain);
    Ypred(i) = predict(gprMdl,Xt);
end
relerr = 100*norm(Ypred-Ytest)^2/norm(Ytest)^2
end




