function y = testfunc1(x)
n = size(x,1);
y = zeros(n,1);
for i = 1:n
    y(i) = (x(i,4) + x(i,2) + x(i,3))*(x(i,5) + x(i,6) + x(i,7) + 1);
end
end