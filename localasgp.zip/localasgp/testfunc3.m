function y = testfunc3(x)
n = size(x,1);
y = zeros(n,1);
for i = 1:n
    if x(i,1) < 0 && x(i,2) < 0
        y(i) = (x(i,4) + x(i,3) + 1)*(x(i,5));
    elseif x(i,1) < 0 && x(i,2) >= 0
        y(i) = (x(i,6) + x(i,7) + 1)*(x(i,9) + x(i,8));
    elseif x(i,1) >= 0 && x(i,2) < 0
        y(i) = (x(i,10) + x(i,11) + 1);
    elseif x(i,1) >= 0 && x(i,2) >= 0
        y(i) = (x(i,12) + 1)*(x(i,13));    
    end
end
end